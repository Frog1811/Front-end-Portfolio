<nav class="navbar">
    <div class="container">
        <div class="logo">Rick.</div>
        <ul class="nav-links">
            <li><a href="index.php">Home</a></li>
            <li><a href="timeline.php">My Journey</a></li>
            <li><a href="Contact.php">Contact</a></li>
        </ul>
    </div>
</nav>